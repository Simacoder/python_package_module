from setuptools import setup

setup(name = 'distribution',
	  version = '0.2',
	  description = 'Gaussian distribution',
	  packages = ['distributions'],
	  zip_safe = False)