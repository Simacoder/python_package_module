from setuptools import setup

setup(name = 'simangadistribution',
	  version = '1.3',
	  description = 'Gaussian distribution',
	  packages = ['binomial_package'],
	  zip_safe = False)